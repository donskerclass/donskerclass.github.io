%geographicequilibrium4.m

%10/11/2015 Updated version
%All scaling errors fixed, generates figures as in draft paper

%Code to calculate the exact solution of the dynamic economic geography
%model described in notes, given a parameterization, and also to construct
%the approximate operators used to find an approximate solution by the
%general algorithm which need not assume eigenfunctions are known

 
tic
%%Parameters

bet=0.96; %Discount rate for intertemporal optimization (0.92)

%Wage Determination parameters, borrowed from Krugman (1996)
sigma=4;        %Elasticity of substitution (3)
tau=0.2;        %Transport costs for goods: normalizes scale of model (0.2)
mu=0.4;         %Share of nontraded goods (0.4)

%Choose whether model defined on real line, or finite circle
%If domain finite, maximum distance is truncated, and characteristic functions are convolved with the sinc function
%Circumference of circle is 1 by default: rescale trade and migration costs relative to this
finitedomain=1; %Set to 1 for finite, 0 for real line: Warning: calculations slightly slow if finite
%Also, finite domain code still buggy: need to ensure that characteristic
%functions accurately computed

%Function representations (in characteristic function form)
nfreq=512;      %number of frequencies used to represent functions (code requires even number to work properly)
freqs=-floor(nfreq/2):floor(nfreq/2);  %Use evenly spaced grid of frequencies for discrete Fourier representation


%Assume rescaling of Gaussian convolution for persistence of aggregate shocks to wages
shockstd=0.04;     %Standard deviation of Gaussian diffusion of initial shock (tested w/ 0.3)
scale=0.98;     %Scale less than 1 ensures stationarity
Gamhat1=scale*exp(-2*((pi*shockstd*freqs).^2)); %Fourier transform of Gaussian flows
%Assume quadratic adjustment costs c(x'-x)=(1/(2*std))*(x'-x)^2
adjstd=0.05;       %Standard deviation of Gaussian flows
Phat1=exp(-2*((pi*adjstd*freqs).^2));     %Fourier transform of Gaussian flows

%Rescale shocks in case of finite domain
gscale=1/(1-2*normcdf(0,1/2,shockstd)); %Truncated Gaussian
Pscale=1/(1-2*normcdf(0,1/2,adjstd));   %Truncated Gaussian
Hscale=1/(1-exp(-0.5*tau*(sigma-1)));   %Truncated Laplace distribution




 %Convolve with sinc function to reflect bounded spatial scale
if finitedomain==1
    Phatcomp=zeros(1,length(freqs));
    Gamhatcomp=zeros(1,length(freqs));
    for j=-floor(nfreq/2):floor(nfreq/2)
        q1=@(x) sinc(x).*exp(-2*((pi*adjstd*(x-j)).^2)); %Product of sinc and fourier transform of P
        q2=@(x) scale*sinc(x).*exp(-2*((pi*shockstd*(x-j)).^2)); %Product of sinc and fourier transform of Gamma
        Phatcomp(j+floor(nfreq/2)+1)=integral(q1,-Inf,Inf);
        Gamhatcomp(j+floor(nfreq/2)+1)=integral(q2,-Inf,Inf);
    end
    Phat=Pscale*Phatcomp;       %Rescale to remain a density
    Gamhat=gscale*Gamhatcomp;   %Rescale to remain a density
else
    Phat=Phat1;
    Gamhat=Gamhat1;
end
        

%Fourier transform of Laplace distribution appearing in wage equation
H1=((sigma-1)^2)./(((sigma-1)^2)+((2*pi*freqs/tau).^2)); 
if finitedomain==1 %Convolve with sinc function to reflect bounded possible movement
    %Sinc integral numerically tricky at some parameter values, but quadrature seems highly accurate regardless
    warning('off', 'MATLAB:integral:MaxIntervalCountReached'); 
    Hcomp=zeros(1,length(freqs));
    for j=-floor(nfreq/2):floor(nfreq/2)
        q3=@(x) sinc(x).*((sigma-1)^2)./(((sigma-1)^2)+((2*pi*(x-j)/tau).^2));
        Hcomp(j+floor(nfreq/2)+1)=integral(q3,-Inf,Inf);
    end
    H=Hscale*Hcomp;     %Rescale to remain a density
else
    H=H1;
end
%Partial derivative of wages with respect to population in static equilibrium
domegadlambda=(1-mu*H).*((mu*H-H.^2)./(sigma-(mu*H+(sigma-1)*H.^2)))-(mu/(1-sigma))*H;




%Construct matrices of partial derivatives with respect to perturbations
%Variables are ordered (lambda, nu, V)
A=zeros(3,3,nfreq+1); %Expected next period values
B=zeros(3,3,nfreq+1); %Derivatives of current values

B(1,3,:)=1; A(1,2,:)=1; A(3,2,:)=1; A(2,1,:)=1; %Identity elements
B(2,1,:)=Phat; B(2,3,:)=bet*Phat-bet*Phat.^2; B(3,2,:)=Gamhat; %Current value derivatives
A(1,1,:)=domegadlambda; A(1,3,:)=bet*Phat; %Next period value derivatives

%Zero frequency follows different pattern: delete equation 2 and variable 1
A0=zeros(2,2); B0=zeros(2,2);
A0(1,1)=1; A0(2,1)=1; B0(1,2)=1; B0(2,1)=Gamhat(floor(nfreq/2)+1); A(1,2)=bet*Phat(floor(nfreq/2)+1);


%Take Generalized Schur decomposition of derivatives
Q1=zeros(3,3,nfreq+1); Q=zeros(3,3,nfreq+1); %Left Schur vectors
Ustar1=zeros(3,3,nfreq+1); Ustar=zeros(3,3,nfreq+1);        %Right Schur vectors
S1=zeros(3,3,nfreq+1); S=zeros(3,3,nfreq+1);        %Upper triangular  
T1=zeros(3,3,nfreq+1); T=zeros(3,3,nfreq+1);        %Upper triangular 
e=zeros(3,nfreq+1);   %(Generalized) Eigenvalues
multeq=zeros(1,nfreq+1); %Check uniqueness of stable equilibrium
nostable=zeros(1,nfreq+1); %Check existence of a stable equilibrium

gx=zeros(1,2,nfreq+1); %Contemporaneous derivative of map from (lambda, nu) to V
hx=zeros(2,2,nfreq+1); %Derivative of law of motion from (lambda, nu) to (lambda',nu')

%Solve for policy functions for all frequencies
for i=1:nfreq+1
    [T1(:,:,i),S1(:,:,i),Q1(:,:,i),Ustar1(:,:,i)]=qz(B(:,:,i),A(:,:,i)); %Take generalized Schur decomposition
    e(:,i)=ordeig(T1(:,:,i),S1(:,:,i));
    if max(abs(e(:,i)))<=1 %If all roots inside circle, there are potentially multiple equilibria 
        multeq(i)=1;
    elseif sum((abs(e(:,i))>1))>1 %If more than 1 root is outside circle, equilibrium is unstable
        nostable(i)=1;
    end
    [T(:,:,i),S(:,:,i),Q(:,:,i),Ustar(:,:,i)]=ordqz(T1(:,:,i),S1(:,:,i),Q1(:,:,i),Ustar1(:,:,i),abs(e(:,i))<=1); %Sort generalized Schur decomposition
    U=squeeze(Ustar(:,:,i))'; %Notation in my paper is transpose of notation in Matlab's qz function
    gx(:,:,i)=-U(3,3)\U(3,1:2);
    m=U(1:2,1:2)+U(1:2,3)*gx(:,:,i);
    hx(:,:,i)=pinv(m)*(S(1:2,1:2,i)\T(1:2,1:2,i))*m;
end

%Repeat process to find policy for 0 frequency
[T10,S10,Q10,Ustar10]=qz(B0,A0); %Take generalized Schur decomposition
e0=ordeig(T10,S10);
if max(abs(e0))<=1 %If all roots inside circle, there are potentially multiple equilibria 
        multeq(floor(nfreq/2)+1)=1;
elseif sum((abs(e0)>1))>1 %If more than 1 root is outside circle, equilibrium is unstable
        nostable(floor(nfreq/2)+1)=1;
else
    multeq(floor(nfreq/2)+1)=0;
    nostable(floor(nfreq/2)+1)=0;
end
[T0,S0,Q0,Ustar0]=ordqz(T10,S10,Q10,Ustar10,abs(e0)<=1); %Sort generalized Schur decomposition
U0=Ustar0'; %Notation in my paper is transpose of notation in Matlab's qz function
gx0=-U0(2,2)\U0(2,1); %Map from nu0 to V0
m=U0(1,1)+U0(1,2)*gx0;
hx0=pinv(m)*(S0(1,1)\T0(1,1))*m; %Map from nu0 to nu0' (should just equal Gamhat(0))

if sum(nostable)>0
    disp('Model is unstable at some frequencies, results invalid');
end
if sum(multeq)>0
    disp('Some frequencies exhibit nonuniqueness: results invalid for those frequencies, but can be fixed');
end

toc
%% Consider limit of operators to get policy "at frequency infinity"

tic 
%These limits assume all transition operators compact: limits may differ
%if, for example, wage shocks do not diffuse spatially
Ainf=[0 1 0; 1 0 0; 0 1 0];
Binf=[0 0 1; 0 0 0; 0 0 0];

[ti, si, qi, ui]=qz(Binf,Ainf);
ei=ordeig(ti,si);
[Ti,Si,Qi,Ustari]=ordqz(ti,si,qi,ui,abs(ei)<=1);
Ui=Ustari'; %Notation in my paper is transpose of notation in Matlab's qz function
gxi=-Ui(3,3)\Ui(3,1:2);
mi=Ui(1:2,1:2)+Ui(1:2,3)*gxi;
hxi=pinv(mi)*(Si(1:2,1:2)\Ti(1:2,1:2))*mi;

%% Represent policy functions in matrix form
hxm=zeros(2*nfreq+2,2*nfreq+2);
gxm=zeros(nfreq+1,2*nfreq+2);
%Place all nfreq+1 frequencies for lambda together, then all nfreq+1 frequencies for nu
gxm(1:end,1:nfreq+1)=diag(squeeze(gx(1,1,:)));
gxm(floor(nfreq/2)+1,floor(nfreq/2)+1)=0; %Delete frequency 0 for lambda
gxm(floor(nfreq/2)+1,nfreq+1+floor(nfreq/2)+1)=gx0; %Replace frequency 0 for nu with correct policy
gxm(1:end,nfreq+2:end)=diag(squeeze(gx(1,2,:)));
hxm(1:nfreq+1,1:nfreq+1)=diag(squeeze(hx(1,1,:)));
hxm(1:nfreq+1,nfreq+2:end)=diag(squeeze(hx(1,2,:)));
hxm(nfreq+2:end,1:nfreq+1)=diag(squeeze(hx(2,1,:)));
hxm(floor(nfreq/2)+1,floor(nfreq/2)+1)=0;
hxm(nfreq+1+floor(nfreq/2)+1,floor(nfreq/2)+1)=0;
hxm(floor(nfreq/2)+1,nfreq+1+floor(nfreq/2)+1)=0;
hxm(nfreq+1+floor(nfreq/2)+1,nfreq+1+floor(nfreq/2)+1)=hx0; %Replace frequency 0 with correct policy 
hxm(nfreq+2:end,nfreq+2:end)=diag(squeeze(hx(2,2,:)));

%% Construct and compare IRFs
testx=zeros(nfreq+1,1);
fmax=100;
testx(floor(nfreq/2)+1-floor(fmax/2):floor(nfreq/2)+1+floor(fmax/2))=1/sqrt(fmax+1); %Consider bandlimited but potentially nonsmooth shock of norm 1
duration=80; %Duration considered
irfX1=zeros(2*nfreq+2,duration); %Impulse response of predetermined variables (lambda,nu)
irfX1(nfreq+2:end,1)=testx; %Initial shock to nu
irfY1=zeros(nfreq+1,duration); %Impulse response of jump variable (V)
irfY1(:,1)=gxm*irfX1(:,1); %Initial response of V
for j=2:duration
    irfX1(:,j)=hxm*irfX1(:,j-1);
    irfY1(:,j)=gxm*irfX1(:,j);
end
figure(1)
surf(irfX1(floor(nfreq/2)+1-floor(fmax/2):floor(nfreq/2)+1+floor(fmax/2),:)), title('Population response to uniform shock by frequency'), xlabel('time'), ylabel('frequency') 
figure(2)
surf(irfX1(nfreq+1+floor(nfreq/2)+1-floor(fmax/2):nfreq+1+floor(nfreq/2)+1+floor(fmax/2),:)), title('Persistence of uniform wage shock by frequency'), xlabel('time'), ylabel('frequency') 
figure(3)
surf(irfY1(floor(nfreq/2)+1-floor(fmax/2):floor(nfreq/2)+1+floor(fmax/2),:)), title('Local welfare response to uniform shock by frequency'), xlabel('time'), ylabel('frequency') 

%% Second, smoother shock function
notzero=zeros(nfreq+1,1); %Offset 0 in index
notzero(floor(nfreq/2)+1)=1;
test2=(abs(freqs'+notzero)).^(-1.2); %Smooth but farther from bandlimited shock
test2=test2/norm(test2); %Normalize energy of shock to 1
irfX2=zeros(2*nfreq+2,duration); %Impulse response of predetermined variables (lambda,nu)
irfX2(nfreq+2:end,1)=test2; %Initial shock to nu
irfY2=zeros(nfreq+1,duration); %Impulse response of jump variable (V)
irfY2(:,1)=gxm*irfX2(:,1); %Initial response of V
for j=2:duration
    irfX2(:,j)=hxm*irfX2(:,j-1);
    irfY2(:,j)=gxm*irfX2(:,j);
end
figure(4)
surf(irfX2(floor(nfreq/2)+1-floor(fmax/2):floor(nfreq/2)+1+floor(fmax/2),:)), title('Population response to smooth shock by frequency'), xlabel('time'), ylabel('frequency') 
figure(5)
surf(irfX2(nfreq+1+floor(nfreq/2)+1-floor(fmax/2):nfreq+1+floor(nfreq/2)+1+floor(fmax/2),:)), title('Persistence of smooth wage shock by frequency'), xlabel('time'), ylabel('frequency') 
figure(6)
surf(irfY2(floor(nfreq/2)+1-floor(fmax/2):floor(nfreq/2)+1+floor(fmax/2),:)), title('Local welfare response to smooth shock by frequency'), xlabel('time'), ylabel('frequency') 

%% Convert to spatial domain
locs=((0:nfreq)/(nfreq+1))'; %Spatial locations
tw=kron(locs,freqs); %space*frequency
convert=exp(2*pi*1i*tw); %Map from fourier components to [0,1] in spatial domain

%convert first shock to spatial domain
irfX1lambda_s=real(convert*irfX1(1:nfreq+1,:));
irfX1nu_s=real(convert*irfX1(nfreq+2:end,:));
irfY1_s=real(convert*irfY1);

figure(7)
surf(0:duration-1,locs,irfX1lambda_s), title('Population response to uniform shock over space'), xlabel('time'), ylabel('space') 
figure(8)
surf(0:duration-1,locs,irfX1nu_s), title('Persistence of uniform wage shock over space'), xlabel('time'), ylabel('space') 
figure(9)
surf(0:duration-1,locs,irfY1_s), title('Local welfare response to uniform shock over space'), xlabel('time'), ylabel('space') 

%convert Second shock to spatial domain
irfX2lambda_s=real(convert*irfX2(1:nfreq+1,:));
irfX2nu_s=real(convert*irfX2(nfreq+2:end,:));
irfY2_s=real(convert*irfY2);

figure(10)
surf(0:duration-1,locs,irfX2lambda_s), title('Population response to smooth shock over space'), xlabel('time'), ylabel('space') 
figure(11)
surf(0:duration-1,locs,irfX2nu_s), title('Persistence of smooth wage shock over space'), xlabel('time'), ylabel('space') 
figure(12)
surf(0:duration-1,locs,irfY2_s), title('Local welfare response to smooth shock over space'), xlabel('time'), ylabel('space') 

%A spatially concentrated shock
aaa=1/2*100000; %Concentration of spatially localized shock
shock1=exp(-((locs-0.5).^2)*aaa); %Gaussian shock in spatial domain
%shockft=real(pinv(convert)*shock1); %Fourier transform of sampled shock
shockft=real(exp(-pi*1i*freqs).*sqrt(pi/aaa).*exp((-(pi*freqs).^2)./aaa))'; %Exact Fourier components of Gaussian shock 
%Above does not take into account finite domain: error negligible for highly spatially concentrated signal

irfX3=zeros(2*nfreq+2,duration); %Impulse response of predetermined variables (lambda,nu)
irfX3(nfreq+2:end,1)=shockft; %Initial shock to nu
irfY3=zeros(nfreq+1,duration); %Impulse response of jump variable (V)
irfY3(:,1)=gxm*irfX3(:,1); %Initial response of V
for j=2:duration
    irfX3(:,j)=hxm*irfX3(:,j-1);
    irfY3(:,j)=gxm*irfX3(:,j);
end
figure(13)
surf(irfX3(floor(nfreq/2)+1-floor(fmax/2):floor(nfreq/2)+1+floor(fmax/2),:)), title('Population response to local shock by frequency'), xlabel('time'), ylabel('frequency') 
figure(14)
surf(irfX3(nfreq+1+floor(nfreq/2)+1-floor(fmax/2):nfreq+1+floor(nfreq/2)+1+floor(fmax/2),:)), title('Persistence of local wage shock by frequency'), xlabel('time'), ylabel('frequency') 
figure(15)
surf(irfY3(floor(nfreq/2)+1-floor(fmax/2):floor(nfreq/2)+1+floor(fmax/2),:)), title('Local welfare response to local shock by frequency'), xlabel('time'), ylabel('frequency') 

irfX3lambda_s=real(convert*irfX3(1:nfreq+1,:));
irfX3nu_s=real(convert*irfX3(nfreq+2:end,:));
irfY3_s=real(convert*irfY3);

figure(16)
surf(0:duration-1,locs,irfX3lambda_s), title('Population response to local shock over space'), xlabel('time'), ylabel('space') 
figure(17)
surf(0:duration-1,locs,irfX3nu_s), title('Persistence of local wage shock over space'), xlabel('time'), ylabel('space') 
figure(18)
surf(0:duration-1,locs,irfY3_s), title('Local welfare response to local shock over space'), xlabel('time'), ylabel('space') 


% %% Sampling
% %  Use Haar wavelets to represent functional derivatives
% %  Code adapted from closedformschur.m adjustment cost model
% %  This method uses wavelet sampling from Fourier basis: in practice, one
% %  would directly perform wavelet transform of integral operators
% 
% mfreq=nfreq; %max Fourier frequency
% R=ceil(log(mfreq)/log(2))-1; %Finest scale of dyadic representation
% m=zeros(mfreq,1);
% ind=1;
% while  ind<=ceil(mfreq/2)
%     m(2*ind)=-ind;
%     if 2*ind+1<=mfreq
%         m(2*ind+1)=ind;
%     end
%     ind=ind+1;
% end
% 
% coefsmat=zeros(mfreq,2^R);
% coefsmat(1,1)=1; %Exact calculation for detail coefficient: both for Fourier and wavelet bases, this is constant term
% 
% %psi_j,k: detail coefficients
% for j=0:R-1 %wavelet scale
%     for k=0:2^j-1 %wavelet translation
%         psi_l=exp(-2*pi*1i*m*(2*k+1/2)/(2^(j+1))).*(2^(-j/2-1)).*sinc(-m/(2^(j+1)));
%         psi_r=exp(-2*pi*1i*m*(2*k+3/2)/(2^(j+1))).*(2^(-j/2-1)).*sinc(-m/(2^(j+1)));
%         psi=psi_l-psi_r;
%         coefsmat(:,2^j+k+1)=psi;
%     end
% end
% 
% %Approximate equilibrium operators
% %For computational reasons, this applies two projections: first, onto first
% %n eigenfunctions, second, from those eigenfunctions onto first k1 or k2
% %Wavelets: identity is kept as identity, however. For n kept large relative to
% %k, this is still a consistent projection
% k1=2^R; %Powers of 2 desirable here because wavelet coefficients only have natural order across scales, not within
% k2=2^(R-1); 
% k3=2^(R-2);
% k4=2^(R-3);
% k5=2^(R-3);
% Mp=zeros(3*k1,3*k2); %Current period
% M2p=Mp; %Tomorrow
% % Mp(1:k1,1:k2)=(1+bet)*conj(coefsmat)'*L*coefsmat(:,1:k2);
% % Mp(1:k2,1:k2)=Mp(1:k2,1:k2)+eye(k2);
% % Mp(1:k1,k2+1:2*k2)=-conj(coefsmat)'*L*coefsmat(:,1:k2);
% % Mp(1:k2,2*k2+1:3*k2)=-eye(k2); 
% % Mp(k1+1:k1+k2,1:k2)=eye(k2);
% % M2p(1:k1,1:k2)=bet*conj(coefsmat)'*L*coefsmat(:,1:k2);
% % M2p(k1+1:k1+k2,k2+1:2*k2)=eye(k2);
% % M2p(2*k1+1:2*k1+k2,2*k2+1:3*k2)=eye(k2); 

%% Numerical integration-based sampling
%  Represent basis functions by applying DWT on approximate sample taken by
%  using samples as Coiflet scaling function coefficients
%  Compared to exact representation, use of DWT potentially induces
%  aliasing, but is asymptotically accurate for smooth inputs

% k1pts=(0:k1-1)./k1; %Sample k1 points in [0,1) for input representation
% k2pts=(0:k2-1)./k2; %Sample k2 points in [0,1) for output representation
% sampgrid=meshgrid(k1pts,k2pts);

%Sample spatial domain evenly
lcs=((0:nfreq-1)/(nfreq))'; %Spatial locations
locsgrid=meshgrid(lcs,lcs);
xminusy=mod(locsgrid-locsgrid'+0.5,1)-0.5; %Wrap distance around to generate circular convolutions


Gam_s=(1/nfreq)*gscale*(scale/sqrt(2*pi*shockstd^2))*exp(-((xminusy).^2)/(2*shockstd^2)); %Kernel of shock transition operator Gamma
H_s=(1/nfreq)*Hscale*(tau*(sigma-1)/2)*exp(-tau*(sigma-1)*(abs(xminusy))); %Kernel of truncated Laplace distribution appearing in wage derivative
P_s=(1/nfreq)*Pscale*(1/sqrt(2*pi*adjstd^2))*exp(-((xminusy).^2)/(2*adjstd^2)); %Kernel of population transition operator P

wname='coif3'; %Coiflets are orthonormal and are approximately interpolating for smooth functions
dwtmode('per'); %Periodized extension used if needed
level=wmaxlev(size(Gam_s),wname); %Get full set of wavelet coefficients

%Compute tensor product wavelet representation by taking dwt of rows, then columns
H_rdec=mdwtdec('r',H_s,level,wname); %Row decomposition
H_row=mdwtrec(H_rdec,'cfs'); %Extract coefficients
H_dec=mdwtdec('c',H_row,level,wname); %Column decomposition
H_coefs=mdwtrec(H_dec,'cfs'); %Extract coefficients
H_coefs=(1/2)*(H_coefs+H_coefs'); %Ensure matrix is exactly Hermitian: raw output deviates by O(10^-17)

Gam_rdec=mdwtdec('r',Gam_s,level,wname); %Row decomposition
Gam_row=mdwtrec(Gam_rdec,'cfs'); %Extract coefficients
Gam_dec=mdwtdec('c',Gam_row,level,wname); %Column decomposition
Gam_coefs=mdwtrec(Gam_dec,'cfs'); %Extract coefficients
Gam_coefs=(1/2)*(Gam_coefs+Gam_coefs'); %Ensure matrix is exactly Hermitian: raw output deviates by O(10^-17)

P_rdec=mdwtdec('r',P_s,level,wname); %Row decomposition
P_row=mdwtrec(P_rdec,'cfs'); %Extract coefficients
P_dec=mdwtdec('c',P_row,level,wname); %Column decomposition
P_coefs=mdwtrec(P_dec,'cfs'); %Extract coefficients
P_coefs=(1/2)*(P_coefs+P_coefs'); %Ensure matrix is exactly Hermitian: raw output deviates by O(10^-17)

shockvec=exp(-((lcs-0.5).^2)/2*100000); %Spatially localized shock from before
[scoef,book_shock]=wavedec(shockvec,level,wname); %Obtain its wavelet coefficients
shtest=waverec(scoef,book_shock,wname); %reconstruct from coefficients to assess error: at 512 coefs, error is O(10^-12)

svec=(1/sqrt(2*pi*0.0001))*exp(-((lcs-0.5).^2)/(2*0.0001)); %Normalized spatially localized signal
[svcoef,book_shockv]=wavedec(svec,level,wname); %Obtain its wavelet coefficients
shtest2=waverec(svcoef,book_shockv,wname); %Reconstruct

dwdl=(eye(nfreq)-(mu/sigma)*H_coefs-((sigma-1)/sigma)*H_coefs^2)\((mu/sigma)*H_coefs-(1/sigma)*H_coefs^2); %Functional derivative of nominal wages with respect to population
domegdl=(eye(nfreq)-mu*H_coefs)*dwdl+(mu/(sigma-1))*H_coefs; %Functional derivative of real wages with respect to population

%Ensure fluctuations of density remain in space of mean 0 vectors by orthogonalizing with respect to constant
consvec=ones(nfreq,1)/sqrt(nfreq); %Sample a constant vector: sampling induces minor error, O(10^-16) at 512 coefficients
[conscoef,book_cons]=wavedec(consvec,level,wname); %Obtain its wavelet coefficients
excoefs=eye(nfreq);
basismat=[conscoef,excoefs(:,2:end)]; %Exclude one vector to prevent redundancy, then generate new orthonormal basis
[Q_demean, Rjunk]=qr(basismat); %Q_demean is orthonormal basis in which constant vector is first element
Qd=Q_demean(:,2:end); %Remove first basis vector

%Represent operators in new orthonormal basis and remove component
%corresponding to mean changes
P_dm=Qd'*P_coefs*Qd; %Transition operator: maps mean 0 input to mean 0 output 
domegdl_dm=domegdl*Qd;%Input is lambda, so demean input, but not output
%To demean identity in transition equation, size is nfreq-1, but identity after change of basis still identity
dldV=Qd'*(bet*P_coefs-bet*P_coefs^2); %derivative of lambda with respect to Value function must have mean 0 output



%Construct matrices of approximate functional derivatives

%%Without demeaning lambda
%Aw=[domegdl,eye(nfreq),bet*P_coefs;eye(nfreq),zeros(nfreq),zeros(nfreq);zeros(nfreq),eye(nfreq),zeros(nfreq)]; %Next period
%Bw=[zeros(nfreq),zeros(nfreq),eye(nfreq);P_coefs,zeros(nfreq),bet*P_coefs-bet*P_coefs^2;zeros(nfreq),Gam_coefs,zeros(nfreq)]; %Current period

%Perturbations in lambda constrained to be mean 0
Aw=[domegdl_dm,eye(nfreq),bet*P_coefs;eye(nfreq-1),zeros(nfreq-1,nfreq),zeros(nfreq-1,nfreq);zeros(nfreq,nfreq-1),eye(nfreq),zeros(nfreq)]; %Next period
Bw=[zeros(nfreq,nfreq-1),zeros(nfreq),eye(nfreq);P_dm,zeros(nfreq-1,nfreq),dldV;zeros(nfreq,nfreq-1),Gam_coefs,zeros(nfreq)]; %Current period

%Construct policy functions on space spanned by wavelet representation
[T1w,S1w,Q1w,Ustar1w]=qz(Bw,Aw,'real'); %Take generalized Schur decomposition %Warning: a little slow: consider thresholding coefficients to reduce size
ew=ordeig(T1w,S1w); 
[Tw,Sw,Qw,Ustarw]=ordqz(T1w,S1w,Q1w,Ustar1w,abs(ew)<=1); %Sort generalized Schur decomposition
Uw=Ustarw'; %Notation in my paper is transpose of notation in Matlab's qz function
gxw=-Uw(end-nfreq+1:end,end-nfreq+1:end)\Uw(end-nfreq+1:end,1:(end-nfreq));
mw=Uw(1:(end-nfreq),1:(end-nfreq))+Uw(1:(end-nfreq),end-nfreq+1:end)*gxw;
hxw=pinv(mw)*(Sw(1:(end-nfreq),1:(end-nfreq))\Tw(1:(end-nfreq),1:(end-nfreq)))*mw;

%% Test output by comparing IRFs
irfXw1=zeros(2*nfreq-1,duration);
irfYw1=zeros(nfreq,duration);
irfXw1(nfreq:end,1)=scoef; %Use wavelet representation of spatially localized shock
irfYw1(:,1)=gxw*irfXw1(:,1);
for j=2:duration
    irfXw1(:,j)=hxw*irfXw1(:,j-1);
    irfYw1(:,j)=gxw*irfXw1(:,j);
end
%convert to spatial representation
irfXw1_lambda_s=zeros(nfreq,duration);
irfXw1_nu_s=zeros(nfreq,duration);
irfYw1_s=zeros(nfreq,duration);
for j=1:duration
    irfXw1_lambda_s(:,j)=waverec(Qd*irfXw1(1:nfreq-1,j),book_shock,wname);
    irfXw1_nu_s(:,j)=waverec(irfXw1(nfreq:end,j),book_shock,wname);
    irfYw1_s(:,j)=waverec(irfYw1(:,j),book_shock,wname);
end

figure(19)
surf(0:duration-1,lcs,irfXw1_lambda_s), title('Approximated Population response to local shock over space'), xlabel('time'), ylabel('space') 
figure(20)
surf(0:duration-1,lcs,irfXw1_nu_s), title('Approximated Persistence of local wage shock over space'), xlabel('time'), ylabel('space') 
figure(21)
surf(0:duration-1,lcs,irfYw1_s), title('Approximated Local welfare response to local shock over space'), xlabel('time'), ylabel('space') 

toc

%% Comparability
% To get pointwise comparison, should be easy: wavelets annoying to take
% off of grid since can't be evaluated in closed form, but Fourier series
% just complex exponentials:

tw2=kron(lcs,freqs); %space*frequency on wavelet grid
convert2=exp(2*pi*1i*tw2); %Map from fourier components to [0,1] in spatial domain

irfX3lambda_s2=real(convert2*irfX3(1:nfreq+1,:));
irfX3nu_s2=real(convert2*irfX3(nfreq+2:end,:));
irfY3_s2=real(convert2*irfY3);

figure(22)
surf(0:duration-1,lcs,irfX3lambda_s2), title('Population response to local shock over space'), xlabel('time'), ylabel('space') 
figure(23)
surf(0:duration-1,lcs,irfX3nu_s2), title('Persistence of local amenity shock over space'), xlabel('time'), ylabel('space') 
figure(24)
surf(0:duration-1,lcs,irfY3_s2), title('Local welfare response to local shock over space'), xlabel('time'), ylabel('space') 

compare_X_nu=irfX3nu_s2-irfXw1_nu_s;
compare_X_l=irfX3lambda_s2-irfXw1_lambda_s;
compare_Y=irfY3_s2-irfYw1_s;

disp('Max nu error')
disp(max(max(abs(compare_X_nu))))
disp('Max lambda error')
disp(max(max(abs(compare_X_l))))
disp('Max V error')
disp(max(max(abs(compare_Y))))

%Calculate empirical l^2 norm error: this is what theorems claim is well controlled 
normerror_X_nu=zeros(duration,1);
normerror_X_l=zeros(duration,1);
normerror_Y=zeros(duration,1);
for i=1:duration
    normerror_X_nu(i)=norm(compare_X_nu(:,i));
    normerror_X_l(i)=norm(compare_X_l(:,i));
    normerror_Y(i)=norm(compare_Y(:,i));
end
    
figure(25),
subplot(3,1,1),plot(normerror_X_nu), title('Euclidean discrepancy in nu'), xlabel('time')
subplot(3,1,2), plot(normerror_X_l), title('Euclidean discrepancy in lambda'), xlabel('time')
subplot(3,1,3), plot(normerror_Y), title('Euclidean discrepancy in V'), xlabel('time')

%% Unit tests: Make sure each component produces reasonable output
%Domegadlambda is complicated: make sure it works on a shock
testomeg=real(convert2*diag(domegadlambda)*shockft); %Fourier representation
testomeg2=waverec(domegdl*scoef,book_shock,wname); %Wavelet representation
%Answer: currently, error is quite large: try to figure out why

%H, P may have problems caused by sinc convolution or wrapping: make sure they work on a shock
testH=real(convert2*diag(H)*shockft); %Fourier representation
testH2=waverec(H_coefs*scoef,book_shock,wname); %Wavelet representation
figure(28)
plot(lcs,testH-testH2), title('H error level'), xlabel('space')

testP=real(convert2*diag(Phat)*shockft); %Fourier representation
testP2=waverec(P_coefs*scoef,book_shock,wname); %Wavelet representation

figure(29)
plot(lcs,testP-testP2), title('P error level'), xlabel('space')

figure(30), plot(lcs,testomeg-testomeg2), title('domegadlambda error level'), xlabel('space')


%% Simulate a time series
tlength=100; %How long
noisestd=0.001; %Scale standard deviation of aggregate shocks
Hurst=0.8; %Hurst index in (0,1) measures degree of spatial autocorrelation of shocks
noiseprocess=zeros(nfreq,tlength);
noisecoeffs=zeros(2*nfreq-1,tlength);
sim_X=zeros(2*nfreq-1,tlength+1);
sim_Y=zeros(nfreq,tlength+1);

rng(7); %Set seed for random number generator to reproduce results
for i=1:tlength
    noiseprocess(:,i)=wfbm(Hurst,nfreq,'coif3')'; %Fractional Brownian motion
end

dwtmode('per'); %wfbm function seems to reset wavelet extension mode

%Simulate law of motion: wavelets
for i=1:tlength  
    [noisecoeffs(nfreq:end,i),irrelevant]=wavedec(noiseprocess(:,i),level,wname);
    sim_X(:,i+1)=hxw*sim_X(:,i)+noisestd*noisecoeffs(:,i);
    sim_Y(:,i+1)=gxw*sim_X(:,i+1);
end



%convert to spatial representation
simX_lambda_s=zeros(nfreq,tlength+1);
simX_nu_s=zeros(nfreq,tlength+1);
simY_s=zeros(nfreq,tlength+1);
for j=1:tlength+1
    simX_lambda_s(:,j)=waverec(Qd*sim_X(1:nfreq-1,j),book_shock,wname);
    simX_nu_s(:,j)=waverec(sim_X(nfreq:end,j),book_shock,wname);
    simY_s(:,j)=waverec(sim_Y(:,j),book_shock,wname);
end

figure(31), surf(0:tlength,lcs,simX_lambda_s), title('Simulated Population Path'), xlabel('time'), ylabel('space')
figure(32), surf(0:tlength,lcs,simX_nu_s), title('Simulated Amenity Shock Path'), xlabel('time'), ylabel('space')
figure(33), surf(0:tlength,lcs,simY_s), title('Simulated Welfare Path'), xlabel('time'), ylabel('space')

% %Simulate law of motion: Fourier
% %Results here are really really bad: probably comes from off by one error
% %in frequency representation since needed to use asymmetric frequencies
% tw3=kron(lcs,freqs(2:end)); %space*frequency on wavelet grid for t frequencies
% convert3=exp(2*pi*1i*tw3); %Map from fourier components to [0,1] in spatial domain
% 
% 
% noisecoeffs2=zeros(2*nfreq,tlength);
% sim_X2=zeros(2*nfreq,tlength+1);
% sim_Y2=zeros(nfreq,tlength+1);
% 
% for i=1:tlength  
%     noisecoeffs2(nfreq+1:end,i)=real(pinv(convert3)*noiseprocess(:,i));
%     sim_X2(:,i+1)=hxm(2:end-1,2:end-1)*sim_X2(:,i)+noisestd*noisecoeffs2(:,i);
%     sim_Y2(:,i+1)=gxm(2:end,2:end-1)*sim_X2(:,i+1);
% end
% 
% %convert to spatial representation
% simX2_lambda_s=real(convert3*sim_X2(1:nfreq,:));
% simX2_nu_s=real(convert3*sim_X2(nfreq+1:end,:));
% simY2_s=real(convert3*sim_Y2);




% %% Evaluation
% %Unfortunately, spatial representations are on slightly different pixel grids
% %Need to interpolate to compare
% 
% %Use higher order accuracy for inputs
% oversample=16; %Degree of oversampling: choose a factor of 2
% lcs2=((0:oversample*nfreq-1)/(oversample*nfreq))';
% shockvec2=exp(-((lcs2-0.5).^2)/2*100000);
% level2=wmaxlev(size(lcs2),wname); %Get full set of wavelet coefficients
% [scoef2,book_shock2]=wavedec(shockvec2,level2,wname); %Obtain its wavelet coefficients
% shtest3=waverec(scoef2,book_shock2,wname); %reconstruct from coefficients to assess error: at 512 coefs, error is O(10^-12)
% recontrunc=waverec(scoef2(1:512),book_shock,wname);
% shift=4; %Right shift induced by Coiflet quadrature
% nrecon=recontrunc(1+shift:end)/sqrt(oversample);
% plot(nrecon-shtest(1:end-shift));
% shsubsample=zeros(nfreq,1);
% for i=1:nfreq
%     shsubsample(i)=shtest3(1+oversample*(i-1));
% end
% figure
% plot(shsubsample-shtest);